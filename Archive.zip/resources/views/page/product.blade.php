@extends('layouts.master')
@section('contents')
@include('inc.nav')


@include('inc.footer')
@endsection